# Phase 5 — Project Development

## Backend Development
The project uses FastAPI as the backend framework.

## Planner Modules

### Home Planner
The /generate-home route handles home-related preferences and budgets and generates recommendations for furniture, decor, and lighting.

### Party Planner
The /generate-party route processes party details and guest counts and provides recommendations for venues, food, and decorations.

### Jewelry Planner
The /generate-jewelry functionality supports text and optional image inputs to suggest jewelry based on outfit style and occasion.

## Authentication
The project includes:
- Registration
- Login
- Logout
- JWT token generation
- Session information
- Session-specific data

## Frontend
The interface includes:
- Home page
- Register page
- Login page
- User dashboard
- Home Interior Budget Planner
- Home Interior Recommendations
- Party Budget Planner
- Party Budget Recommendations
- Jewelry Budget Planner
- Jewelry Budget Recommendations
- Recommendation History
- Testimonials and footer sections
