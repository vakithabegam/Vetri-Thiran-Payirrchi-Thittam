# Phase 2 — Requirement Analysis

## Functional Requirements

### Home Interior Planner
- Accept a home budget.
- Accept room types and quantities for items such as lights, ceiling fans, and dining tables.
- Generate cost-effective recommendations.
- Consider functionality, style, and price.

### Party Planner
- Accept total budget.
- Accept guest count.
- Accept event type and venue details.
- Allocate budget across catering, decoration, and entertainment.
- Provide recommendations for event planning.

### Jewelry Planner
- Accept budget, occasion, and style preferences.
- Allow optional outfit image upload.
- Analyze color coordination and aesthetics.
- Generate matching jewelry recommendations.

### User Authentication
- Registration
- Login
- Logout
- JWT token generation
- Session information
- Session-specific data

### Recommendation History
- Store and display previous recommendation queries and results.

## Technical Requirements
- Python
- FastAPI backend
- HTML/CSS/JavaScript frontend
- Jinja2 templates
- Gemini 1.5 Flash Pro
- Third-party platform/product data sources
- CORS support
- Session management
