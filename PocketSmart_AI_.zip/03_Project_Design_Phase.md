# Phase 3 — Project Design

## Architecture Overview
PocketSmart AI uses a modular architecture connecting a frontend interface, a FastAPI backend, and the Gemini AI recommendation layer.

## Main Components

### Frontend UI
Built using HTML/CSS and JavaScript/Jinja2 templates. It collects budgets, preferences, and optional images and displays AI-generated recommendations.

### FastAPI Backend
Handles routing, user authentication, sessions, planner modules, and communication with Gemini AI.

### Gemini AI Layer
Processes user inputs using Gemini 1.5 Flash Pro to understand budgets, analyze images where applicable, and generate structured recommendations.

### External Data Sources
The project documentation identifies platforms such as Amazon, Flipkart, IKEA, Zomato, Swiggy, and OYO as sources for product/service recommendations.

## Main Routes
- /generate-home
- /generate-party
- /generate-jewelry
- /register
- /login
- /logout
- /token
- /session-info
- /session-data
- /recommendations-details
- /history
- /startup
