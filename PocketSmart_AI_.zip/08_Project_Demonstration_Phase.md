# Phase 8 — Project Demonstration

## Demonstration Flow

### 1. Home Page
Show the PocketSmart AI landing page and its main features.

### 2. User Registration
Demonstrate creation of a user account.

### 3. Login
Demonstrate authentication of an existing user.

### 4. User Dashboard
Show recent recommendations, saved queries, and personalized information.

### 5. Home Interior Planner
- Enter a budget.
- Select room details and quantities.
- Generate recommendations.
- Show the recommendation results.

### 6. Party Planner
- Enter event type.
- Enter budget and guest count.
- Generate recommendations for food, venue, and decoration.

### 7. Jewelry Planner
- Enter budget, occasion, and style preferences.
- Optionally upload an outfit image.
- Generate matching jewelry recommendations.

### 8. Recommendation History
Show previous recommendation queries and results.

## Demo Video
Record a complete project demonstration covering the major features above and upload the video to Google Drive as required by the submission instructions.
