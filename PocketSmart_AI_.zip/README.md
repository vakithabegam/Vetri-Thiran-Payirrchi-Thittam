# PocketSmart AI — Phase-wise Project Submission

This folder contains the project documentation organized according to the required eight submission phases.

1. Brainstorming & Ideation Phase
2. Requirement Analysis Phase
3. Project Design Phase
4. Project Planning Phase
5. Project Development Phase
6. Project Testing Phase
7. Project Documentation Phase
8. Project Demonstration Phase

## Project
PocketSmart AI: Your Smart Budget & Recommendation Assistant

## Submission Items
- Public GitHub Repository Link
- Complete project files/documents organized phase-wise
- Complete project demonstration video
- Google Drive link for the demonstration video
