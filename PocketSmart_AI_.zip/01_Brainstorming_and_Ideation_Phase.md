# Phase 1 — Brainstorming & Ideation

## Project Title
PocketSmart AI: Your Smart Budget & Recommendation Assistant

## Project Idea
PocketSmart AI is a GenAI-powered, cross-platform recommendation system that provides personalized, budget-based suggestions for products and services.

## Problem Identified
Managing budgets for needs such as home decor, event planning, and jewelry shopping can be difficult because of the wide variety of products, platforms, and price ranges.

## Proposed Solution
The system uses user preferences, budgets, and contextual needs to generate curated recommendations across multiple platforms.

## Main Use Cases
1. Home Interior Planning
2. Party Budget Planning
3. Jewelry Recommendations

## AI Component
Gemini 1.5 Flash Pro is used to understand budget context, generate recommendations, and analyze optional outfit images for the Jewelry Planner.

## Expected Benefit
PocketSmart AI aims to make budgeting and planning more intelligent, user-friendly, personalized, and budget-aware.
